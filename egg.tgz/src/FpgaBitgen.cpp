// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Generate FPGA bitfile"); }
int main(){
  announce();
  return lionss_run_workload("FpgaBitgen");
}
