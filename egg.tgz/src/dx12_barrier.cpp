// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Insert resource barriers"); }
int main(){
  announce();
  return lionss_run_workload("dx12_barrier");
}
