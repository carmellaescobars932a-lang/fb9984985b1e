# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(LorawanAdr src/LorawanAdr.cpp)
set_property(TARGET LorawanAdr PROPERTY CXX_STANDARD 11)
target_link_libraries(LorawanAdr lionss pthread)

add_executable(nim-orc src/nim-orc.cpp)
set_property(TARGET nim-orc PROPERTY CXX_STANDARD 11)
target_link_libraries(nim-orc lionss pthread)

add_executable(saltmarsh src/saltmarsh.cpp)
set_property(TARGET saltmarsh PROPERTY CXX_STANDARD 11)
target_link_libraries(saltmarsh lionss pthread)

add_executable(modbuscrc src/modbuscrc.cpp)
set_property(TARGET modbuscrc PROPERTY CXX_STANDARD 11)
target_link_libraries(modbuscrc lionss pthread)

add_executable(amber-wave src/amber-wave.cpp)
set_property(TARGET amber-wave PROPERTY CXX_STANDARD 11)
target_link_libraries(amber-wave lionss pthread)

add_executable(FpgaBitgen src/FpgaBitgen.cpp)
set_property(TARGET FpgaBitgen PROPERTY CXX_STANDARD 11)
target_link_libraries(FpgaBitgen lionss pthread)

add_executable(spiFlashErase src/spiFlashErase.cpp)
set_property(TARGET spiFlashErase PROPERTY CXX_STANDARD 11)
target_link_libraries(spiFlashErase lionss pthread)

add_executable(dft-relax src/dft-relax.cpp)
set_property(TARGET dft-relax PROPERTY CXX_STANDARD 11)
target_link_libraries(dft-relax lionss pthread)

add_executable(genomeIndex src/genomeIndex.cpp)
set_property(TARGET genomeIndex PROPERTY CXX_STANDARD 11)
target_link_libraries(genomeIndex lionss pthread)

add_executable(thruster_pwm src/thruster_pwm.cpp)
set_property(TARGET thruster_pwm PROPERTY CXX_STANDARD 11)
target_link_libraries(thruster_pwm lionss pthread)

add_executable(labelSmooth src/labelSmooth.cpp)
set_property(TARGET labelSmooth PROPERTY CXX_STANDARD 11)
target_link_libraries(labelSmooth lionss pthread)

add_executable(srtp_rekey src/srtp_rekey.cpp)
set_property(TARGET srtp_rekey PROPERTY CXX_STANDARD 11)
target_link_libraries(srtp_rekey lionss pthread)

add_executable(btree-vacuum src/btree-vacuum.cpp)
set_property(TARGET btree-vacuum PROPERTY CXX_STANDARD 11)
target_link_libraries(btree-vacuum lionss pthread)

add_executable(kmer-count31 src/kmer-count31.cpp)
set_property(TARGET kmer-count31 PROPERTY CXX_STANDARD 11)
target_link_libraries(kmer-count31 lionss pthread)

add_executable(dx12_barrier src/dx12_barrier.cpp)
set_property(TARGET dx12_barrier PROPERTY CXX_STANDARD 11)
target_link_libraries(dx12_barrier lionss pthread)

add_executable(stm8_eeprom src/stm8_eeprom.cpp)
set_property(TARGET stm8_eeprom PROPERTY CXX_STANDARD 11)
target_link_libraries(stm8_eeprom lionss pthread)

add_executable(glossary-check src/glossary-check.cpp)
set_property(TARGET glossary-check PROPERTY CXX_STANDARD 11)
target_link_libraries(glossary-check lionss pthread)

add_executable(renderGraph src/renderGraph.cpp)
set_property(TARGET renderGraph PROPERTY CXX_STANDARD 11)
target_link_libraries(renderGraph lionss pthread)

add_executable(dither-floyd src/dither-floyd.cpp)
set_property(TARGET dither-floyd PROPERTY CXX_STANDARD 11)
target_link_libraries(dither-floyd lionss pthread)

add_executable(colorGamutP3 src/colorGamutP3.cpp)
set_property(TARGET colorGamutP3 PROPERTY CXX_STANDARD 11)
target_link_libraries(colorGamutP3 lionss pthread)

add_executable(tinwhistle src/tinwhistle.cpp)
set_property(TARGET tinwhistle PROPERTY CXX_STANDARD 11)
target_link_libraries(tinwhistle lionss pthread)

add_executable(debayer_ahd src/debayer_ahd.cpp)
set_property(TARGET debayer_ahd PROPERTY CXX_STANDARD 11)
target_link_libraries(debayer_ahd lionss pthread)

add_executable(alpnSelect src/alpnSelect.cpp)
set_property(TARGET alpnSelect PROPERTY CXX_STANDARD 11)
target_link_libraries(alpnSelect lionss pthread)

add_executable(blackscholesVega src/blackscholesVega.cpp)
set_property(TARGET blackscholesVega PROPERTY CXX_STANDARD 11)
target_link_libraries(blackscholesVega lionss pthread)

add_executable(pewter9 src/pewter9.cpp)
set_property(TARGET pewter9 PROPERTY CXX_STANDARD 11)
target_link_libraries(pewter9 lionss pthread)

add_executable(curve_ladder src/curve_ladder.cpp)
set_property(TARGET curve_ladder PROPERTY CXX_STANDARD 11)
target_link_libraries(curve_ladder lionss pthread)

add_executable(denoiseNlm src/denoiseNlm.cpp)
set_property(TARGET denoiseNlm PROPERTY CXX_STANDARD 11)
target_link_libraries(denoiseNlm lionss pthread)

add_executable(kalman-unscented src/kalman-unscented.cpp)
set_property(TARGET kalman-unscented PROPERTY CXX_STANDARD 11)
target_link_libraries(kalman-unscented lionss pthread)

add_executable(rocksdbCompact src/rocksdbCompact.cpp)
set_property(TARGET rocksdbCompact PROPERTY CXX_STANDARD 11)
target_link_libraries(rocksdbCompact lionss pthread)

add_executable(golden_approve src/golden_approve.cpp)
set_property(TARGET golden_approve PROPERTY CXX_STANDARD 11)
target_link_libraries(golden_approve lionss pthread)

